package com.example.projeto_android

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.projeto_android.databinding.MainImcBinding
import java.util.Locale
import android.widget.TextView

class MainIMC : AppCompatActivity() {

    private lateinit var binding: MainImcBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = MainImcBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        binding.btCalcularIMC.setOnClickListener {
            // Obter os valores dos EditTexts
            val pesoTexto = binding.editPesoIMC.text.toString()
            val alturaTexto = binding.editAlturaIMC.text.toString()

            if (pesoTexto.isNotEmpty() && alturaTexto.isNotEmpty()) {
                // Converter os valores de peso e altura para números
                val peso = pesoTexto.toDouble()
                val altura = alturaTexto.toDouble()

                // Calcular o IMC
                val imc = calcularIMC(peso, altura)

                // Exibir o resultado formatado no TextView
                formatResultadoIMC(imc, binding.txtResultadoIMC)

                // Determinar a situação do IMC e exibir
                exibirSituacaoIMC(imc, binding.txtSituacaoIMC)
            } else {
                // Exibir uma mensagem de erro se algum dos campos estiver vazio
                if (pesoTexto.isEmpty()) {
                    binding.editPesoIMC.error = "Informe o peso"
                }
                if (alturaTexto.isEmpty()) {
                    binding.editAlturaIMC.error = "Informe a altura"
                }
            }
        }
    }

    private fun calcularIMC(peso: Double, altura: Double): Double {
        // Fórmula do IMC: peso / altura^2
        return peso / (altura * altura)
    }

    private fun formatResultadoIMC(imc: Double, txtResultado: TextView) {
        // Exibir o resultado formatado no TextView
        txtResultado.text = String.format(Locale.getDefault(), "Seu IMC é %.2f.", imc)
    }

    private fun exibirSituacaoIMC(imc: Double, txtSituacao: TextView) {
        // Determinar a situação do IMC
        val situacao: String = when {
            imc < 18.5 -> "Abaixo do Normal"
            imc < 24.9 -> "Normal"
            imc < 29.9 -> "Sobrepeso"
            imc < 34.9 -> "Obesidade Grau 1"
            imc < 39.9 -> "Obesidade Grau 2"
            else -> "Obesidade Grau 3"
        }

        // Exibir a situação no TextView
        txtSituacao.text = "Situação: $situacao"
    }
}
