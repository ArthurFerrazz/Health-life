package com.example.projeto_android

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.projeto_android.databinding.MainHomeBinding

class MainHome : AppCompatActivity() {

    private lateinit var binding: MainHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicialize o binding antes de usar
        binding = MainHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        binding.btWater.setOnClickListener {
            val navegarAgua = Intent(this, MainWater::class.java)
            startActivity(navegarAgua)
        }

        binding.btProtein.setOnClickListener {
            val navegarProtein = Intent(this, MainProtein::class.java)
            startActivity(navegarProtein)
        }

        binding.btIMC.setOnClickListener {
            val navegarIMC = Intent(this, MainIMC::class.java)
            startActivity(navegarIMC)
        }
    }
}
