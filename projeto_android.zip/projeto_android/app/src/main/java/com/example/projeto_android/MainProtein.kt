package com.example.projeto_android

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.projeto_android.databinding.MainProteinBinding
import java.util.Locale
import android.widget.TextView

class MainProtein : AppCompatActivity() {

    private lateinit var binding: MainProteinBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = MainProteinBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        binding.btCalcularProteina.setOnClickListener {
            // Obter o valor do EditText
            val pesoTexto = binding.editPesoProteina.text.toString()

            if (pesoTexto.isNotEmpty()) {
                // Converter o valor do peso para a quantidade ideal de proteína
                val peso = pesoTexto.toDouble()
                val quantidadeProteina = calcularQuantidadeProteina(peso)

                // Exibir o resultado formatado no TextView
                formatResultado(quantidadeProteina, binding.txtResultadoProteina)
            } else {
                // Exibir uma mensagem de erro se o campo estiver vazio
                binding.editPesoProteina.error = "Informe o peso"
            }
        }
    }

    private fun calcularQuantidadeProteina(peso: Double): Double {
        // Você pode ajustar o fator multiplicativo com base em recomendações específicas
        // Recomendações comuns variam de 0.8 a 2.2 gramas por quilo de peso corporal
        return peso * 0.8
    }

    private fun formatResultado(quantidadeProteina: Double, txtResultado: TextView) {
        // Formatando o resultado para exibir apenas duas casas decimais
        val resultadoFormatado = String.format(Locale.getDefault(), "%.2f", quantidadeProteina)

        // Exibir o resultado formatado no TextView
        txtResultado.text = "Quantidade diária mínima de proteína: $resultadoFormatado g."
    }
}
