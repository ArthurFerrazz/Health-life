package com.example.projeto_android

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.projeto_android.databinding.MainWaterBinding
import java.util.Locale
import android.widget.TextView


class MainWater : AppCompatActivity() {

    private lateinit var binding: MainWaterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = MainWaterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()



        binding.btCalcular.setOnClickListener {
            // Obter o valor do EditText
            val pesoTexto = binding.editPeso.text.toString()

            if (pesoTexto.isNotEmpty()) {
                // Converter o valor do peso para a quantidade ideal de água
                val peso = pesoTexto.toDouble()
                val quantidadeAgua = calcularQuantidadeAgua(peso)

                // Exibir o resultado formatado no TextView
                formatResultado(quantidadeAgua, binding.txtResultado)
            } else {
                // Exibir uma mensagem de erro se o campo estiver vazio
                binding.editPeso.error = "Informe o peso"
            }
        }
    }

    private fun calcularQuantidadeAgua(peso: Double): Double {
        return peso * 0.035
    }

    private fun formatResultado(quantidadeAgua: Double, txtResultado: TextView) {
        // Formatando o resultado para exibir apenas duas casas decimais
        val resultadoFormatado = String.format(Locale.getDefault(), "%.3f", quantidadeAgua)

        // Exibir o resultado formatado no TextView
        txtResultado.text = "Quantidade diária ideal de água: $resultadoFormatado ml."
    }
}
